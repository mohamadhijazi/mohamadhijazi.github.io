﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Simple
    {
        public string Speech { get; set; }
        public string Text { get; set; }
    }
}