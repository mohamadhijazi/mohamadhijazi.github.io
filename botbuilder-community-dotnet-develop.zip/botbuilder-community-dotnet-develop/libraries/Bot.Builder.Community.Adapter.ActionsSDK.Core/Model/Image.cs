﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Image
    {
        public string Url { get; set; }
        public string Alt { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }
    }
}