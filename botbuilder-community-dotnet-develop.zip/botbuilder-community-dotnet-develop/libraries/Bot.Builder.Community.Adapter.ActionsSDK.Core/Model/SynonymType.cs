﻿using System.Collections.Generic;

namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class SynonymType
    {
        public List<Entry> Entries { get; set; }
    }
}