﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class NextScene
    {
        public string Name { get; set; }
    }
}