﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Link
    {
        public string Name { get; set; }

        public OpenUrl Open { get; set; }
    }
}