﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class TableCell
    {
        public string Text { get; set; }
    }
}