﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class ImageContentItem : ContentItem
    {
        public Image Image { get; set; }
    }
}
