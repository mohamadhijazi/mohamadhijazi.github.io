﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class MediaImage
    {
        public Image Image { get; set; }
        public Image Icon { get; set; }
    }
}