﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class TableContentItem : ContentItem
    {
        public Table Table { get; set; }
    }
}