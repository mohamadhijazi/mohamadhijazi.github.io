﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public abstract class ContentItem { }
}