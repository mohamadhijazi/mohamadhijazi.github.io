﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class TableColumn
    {
        public string Header { get; set; }
        public HorizontalAlignment Align { get; set; }
    }
}