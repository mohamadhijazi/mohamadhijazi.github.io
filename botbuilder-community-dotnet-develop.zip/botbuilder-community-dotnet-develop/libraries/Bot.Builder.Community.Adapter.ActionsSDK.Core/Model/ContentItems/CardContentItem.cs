﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class CardContentItem : ContentItem
    {
        public Card Card { get; set; }
    }
}