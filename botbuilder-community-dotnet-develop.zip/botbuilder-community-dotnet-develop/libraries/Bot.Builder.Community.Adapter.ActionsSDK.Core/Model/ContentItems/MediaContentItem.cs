﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class MediaContentItem : ContentItem
    {
        public Media Media { get; set; }
    }
}