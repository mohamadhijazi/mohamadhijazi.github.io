﻿using System.Collections.Generic;

namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model.ContentItems
{
    public class TableRow
    {
        public List<TableCell> Cells { get; set; }
    }
}