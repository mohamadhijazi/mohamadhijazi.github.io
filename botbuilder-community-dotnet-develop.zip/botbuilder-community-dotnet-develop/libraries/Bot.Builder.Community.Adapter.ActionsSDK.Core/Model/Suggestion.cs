﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Suggestion
    {
        public string Title { get; set; }
    }
}