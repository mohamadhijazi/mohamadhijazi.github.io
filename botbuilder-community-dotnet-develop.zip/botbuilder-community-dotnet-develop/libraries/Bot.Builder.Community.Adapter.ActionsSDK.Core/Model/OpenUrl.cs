﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class OpenUrl
    {
        public string Url { get; set; }

        public string Hint { get; set; }
    }
}