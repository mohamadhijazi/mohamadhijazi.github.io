﻿using System.Collections.Generic;

namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Device
    {
        public List<string> Capabilities { get; set; }
    }
}