﻿using System.Collections.Generic;

namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Expected
    {
        public List<string> Speech { get; set; }

        public string LanguageCode { get; set; }
    }
}