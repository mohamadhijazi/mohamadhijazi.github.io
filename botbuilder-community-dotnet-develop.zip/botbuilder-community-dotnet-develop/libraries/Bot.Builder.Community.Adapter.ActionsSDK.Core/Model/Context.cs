﻿using Newtonsoft.Json.Linq;

namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Context
    {
        public JObject Media { get; set; }
    }
}