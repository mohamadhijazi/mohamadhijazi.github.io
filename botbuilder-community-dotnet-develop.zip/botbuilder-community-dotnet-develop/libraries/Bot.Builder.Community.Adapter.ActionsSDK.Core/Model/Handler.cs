﻿namespace Bot.Builder.Community.Adapters.ActionsSDK.Core.Model
{
    public class Handler
    {
        public string Name { get; set; }
    }
}