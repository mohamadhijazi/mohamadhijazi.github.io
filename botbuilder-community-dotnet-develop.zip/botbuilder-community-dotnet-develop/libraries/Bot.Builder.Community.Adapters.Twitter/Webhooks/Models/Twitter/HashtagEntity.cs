﻿namespace Bot.Builder.Community.Adapters.Twitter.Webhooks.Models.Twitter
{
    public class HashtagEntity
    {

        public string text { get; set; }
        public int[] indices { get; set; }

    }
}
