﻿namespace Bot.Builder.Community.Adapters.Twitter.Webhooks.Models.Twitter
{
    public class UrlEntity
    {
        public string url { get; set; }
        public string expanded_url { get; set; }
        public string display_url { get; set; }
        public int[] indices { get; set; }
    }
}
