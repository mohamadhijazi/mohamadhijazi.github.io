﻿namespace Bot.Builder.Community.Adapters.Twitter.Webhooks.Models
{
    public enum TwitterEventType
    {
        MessageCreate,
        Unknown
    }
}
