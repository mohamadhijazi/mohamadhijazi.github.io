﻿namespace Bot.Builder.Community.Adapters.Zoom
{
    public class ZoomRequestMapperOptions
    {
        public string RobotJid { get; set; }
    }
}
