﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class ZoomSelectItem
    {
        public string Text { get; set; }
        public string Value { get; set; }
        public Style Style { get; set; }
    }
}