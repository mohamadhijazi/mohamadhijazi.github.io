﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class ZoomAttachmentInfo
    {
        public ZoomAttachmentInfoContent Title { get; set; }

        public ZoomAttachmentInfoContent Description { get; set; }
    }
}