﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class SubHead
    {
        public string Text { get; set; }

        public Style Style { get; set; }
    }
}