﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class BodyItem
    {
    }
}