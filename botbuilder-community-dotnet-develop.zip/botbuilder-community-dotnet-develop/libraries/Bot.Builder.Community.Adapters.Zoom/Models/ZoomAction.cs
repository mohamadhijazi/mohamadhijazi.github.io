﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class ZoomAction
    {
        public string Text { get; set; }
        public string Value { get; set; }
        public string Style { get; set; }
    }
}