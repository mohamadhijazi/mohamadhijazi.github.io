﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class Style
    {
        public string Color { get; set; }
        public bool Bold { get; set; }
        public bool Italic { get; set; }
    }
}