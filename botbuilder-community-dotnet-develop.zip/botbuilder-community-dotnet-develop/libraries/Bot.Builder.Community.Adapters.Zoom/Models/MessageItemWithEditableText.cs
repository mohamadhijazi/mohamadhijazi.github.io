﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class MessageItemWithEditableText : MessageItem
    {
        public bool Editable { get; set; } = true;
    }
}