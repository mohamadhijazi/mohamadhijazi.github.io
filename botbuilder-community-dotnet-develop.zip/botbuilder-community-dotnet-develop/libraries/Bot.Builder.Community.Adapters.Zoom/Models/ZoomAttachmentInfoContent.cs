﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class ZoomAttachmentInfoContent
    {
        public string Text { get; set; }
        public Style Style { get; set; }
    }
}