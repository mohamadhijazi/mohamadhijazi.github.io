﻿namespace Bot.Builder.Community.Adapters.Zoom.Models
{
    public class MessageBodyItemWithLink : MessageItem
    {
        public string Link { get; set; }
    }
}