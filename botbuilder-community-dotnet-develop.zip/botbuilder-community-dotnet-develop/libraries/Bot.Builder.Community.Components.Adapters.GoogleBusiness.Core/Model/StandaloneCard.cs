﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class StandaloneCard
    {
        public CardContent CardContent { get; set; }
    }
}