﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class Image
    {
        public ContentInfo ContentInfo { get; set; }
    }
}