﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class OpenUrlAction
    {
        public string Url { get; set; }
    }
}