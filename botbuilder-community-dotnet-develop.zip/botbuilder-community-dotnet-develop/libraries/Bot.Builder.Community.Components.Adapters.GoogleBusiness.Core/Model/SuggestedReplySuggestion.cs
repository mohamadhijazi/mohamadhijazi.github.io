﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class SuggestedReplySuggestion : Suggestion
    {
        public SuggestedReply Reply { get; set; }
    }
}