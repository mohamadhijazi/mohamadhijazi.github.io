﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class SuggestedReply
    {
        public string Text { get; set; }
        public string PostbackData { get; set; }
    }
}