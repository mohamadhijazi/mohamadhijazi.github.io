﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class Representative
    {
        public string AvatarImage { get; set; }
        public string DisplayName { get; set; }
        public string RepresentativeType { get; set; }
    }
}