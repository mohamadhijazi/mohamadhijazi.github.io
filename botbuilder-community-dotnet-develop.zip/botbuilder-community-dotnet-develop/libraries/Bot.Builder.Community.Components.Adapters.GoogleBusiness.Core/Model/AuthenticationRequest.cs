﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class AuthenticationRequest
    {
        public OAuth OAuth { get; set; }
    }
}