﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class DialAction
    {
        public string PhoneNumber { get; set; }
    }
}