﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class AuthenticationRequestSuggestion : Suggestion
    {
        public AuthenticationRequest OAuth { get; set; }
    }
}