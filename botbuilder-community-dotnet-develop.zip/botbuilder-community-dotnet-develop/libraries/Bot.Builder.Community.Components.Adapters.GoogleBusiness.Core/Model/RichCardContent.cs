﻿using System;
using System.Text;
using Microsoft.Bot.Schema;

namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class RichCardContent
    {
        public StandaloneCard StandaloneCard { get; set; }
    }
}