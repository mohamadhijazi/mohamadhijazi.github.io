﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class Receipt
    {
        public string Message { get; set; }
        public string ReceiptType { get; set; }
    }
}