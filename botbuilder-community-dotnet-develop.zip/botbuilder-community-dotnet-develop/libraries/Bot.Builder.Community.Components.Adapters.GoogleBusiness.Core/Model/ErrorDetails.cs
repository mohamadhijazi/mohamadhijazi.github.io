﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class ErrorDetails
    {
        public string Error { get; set; }
        public string ErrorDescription { get; set; }
    }
}