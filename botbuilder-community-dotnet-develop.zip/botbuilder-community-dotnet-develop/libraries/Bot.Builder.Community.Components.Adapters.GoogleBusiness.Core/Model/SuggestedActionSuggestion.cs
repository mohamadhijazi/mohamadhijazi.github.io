﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class SuggestedActionSuggestion : Suggestion
    {
        public SuggestedAction Action { get; set; }
    }
}