﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class LiveAgentRequestSuggestion : Suggestion
    {
        public LiveAgentRequest LiveAgentRequest { get; set; } = new LiveAgentRequest();
    }
}