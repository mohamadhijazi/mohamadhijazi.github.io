﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class SuggestionResponse
    {
        public string Message { get; set; }
        public string PostbackData { get; set; }
        public string CreateTime { get; set; }
        public string Text { get; set; }
        public string Type { get; set; }
    }
}