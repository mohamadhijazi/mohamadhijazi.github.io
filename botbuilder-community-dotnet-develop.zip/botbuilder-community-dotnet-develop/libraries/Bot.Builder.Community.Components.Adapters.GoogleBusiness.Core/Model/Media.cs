﻿namespace Bot.Builder.Community.Components.Adapters.GoogleBusiness.Core.Model
{
    public class Media
    {
        public string Height { get; set; }
        public ContentInfo ContentInfo { get; set; }
    }
}