﻿namespace Bot.Builder.Community.Adapters.RingCentral.Schema
{
    public class ContextData
    {
        public string ActivityId { get; set; }

        public string ChannelId { get; set; }
    }
}
