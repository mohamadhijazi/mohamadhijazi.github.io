﻿namespace Bot.Builder.Community.Adapters.RingCentral.Schema
{
    public class RingCentralMetadata
    {
        public bool IsHumanResponse { get; set; }
    }
}
