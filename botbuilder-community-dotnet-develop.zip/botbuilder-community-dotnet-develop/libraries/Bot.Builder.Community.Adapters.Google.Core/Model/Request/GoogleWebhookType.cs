﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Request
{
    public enum GoogleWebhookType
    {
        DialogFlow,
        Conversation
    }
}
