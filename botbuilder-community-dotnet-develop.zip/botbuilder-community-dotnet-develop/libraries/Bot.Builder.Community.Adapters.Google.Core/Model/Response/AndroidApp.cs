﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Response
{
    public class AndroidApp
    {
        public string PackageName { get; set; }
        public VersionFilter[] Versions { get; set; }
    }
}