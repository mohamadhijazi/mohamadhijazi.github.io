﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Response
{
    public class InputPrompt
    {
        public RichResponse RichInitialPrompt { get; set; }
    }
}