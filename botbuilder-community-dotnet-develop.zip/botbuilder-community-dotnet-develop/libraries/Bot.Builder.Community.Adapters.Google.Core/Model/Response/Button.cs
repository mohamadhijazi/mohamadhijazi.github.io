﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Response
{
    public class Button
    {
        public string Title { get; set; }
        public OpenUrlAction OpenUrlAction { get; set; }
    }
}