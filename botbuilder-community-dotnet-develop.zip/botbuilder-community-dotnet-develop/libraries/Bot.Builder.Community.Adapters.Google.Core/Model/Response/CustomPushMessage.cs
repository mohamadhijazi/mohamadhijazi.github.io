﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Response
{
    public class CustomPushMessage
    {
    }
}