﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Response
{
    public class VersionFilter
    {
        public double MinVersion { get; set; }
        public double MaxVersion { get; set; }
    }
}