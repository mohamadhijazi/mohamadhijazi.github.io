﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Response
{
    public class DialogFlowResponse
    {
        public ResponsePayload Payload { get; set; }
    }
}