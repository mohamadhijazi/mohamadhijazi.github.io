﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.Response
{
    public class Suggestion
    {
        public string Title { get; set; }
    }
}