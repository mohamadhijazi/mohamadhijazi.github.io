﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.SystemIntents
{
    public class TextIntent : SystemIntent
    {
        public TextIntent()
        {
            Intent = "actions.intent.TEXT";
        }
    }
}