﻿namespace Bot.Builder.Community.Adapters.Google.Core.Model.SystemIntents
{
    public abstract class SystemIntent
    {
        public string Intent { get; set; }
    }
}