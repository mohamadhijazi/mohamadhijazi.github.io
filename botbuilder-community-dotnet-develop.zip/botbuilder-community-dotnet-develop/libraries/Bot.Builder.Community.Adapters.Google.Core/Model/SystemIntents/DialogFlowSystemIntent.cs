﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bot.Builder.Community.Adapters.Google.Core.Model.SystemIntents
{
    public class DialogFlowSystemIntent : SystemIntent
    {
        public object Data { get; set; }
    }
}
