﻿using Bot.Builder.Community.Adapters.Infobip.Core;

namespace Bot.Builder.Community.Adapters.Infobip.Sms
{
    public interface IInfobipSmsClient: IInfobipClientBase
    {
    }
}
