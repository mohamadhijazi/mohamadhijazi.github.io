﻿namespace Bot.Builder.Community.Adapters.Slack.Model.Model
{
    public class SlackTeam
    {
        public string Id { get; set; }

        public string Domain { get; set; }
    }
}
