﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Bot.Builder.Community.Cards.Tests")]
