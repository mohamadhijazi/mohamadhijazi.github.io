﻿namespace Bot.Builder.Community.Cards.Management
{
    internal class EntityTypes
    {
        public const string Intent = "Intent";
    }
}