﻿namespace Bot.Builder.Community.Cards.Management
{
    public class BehaviorSwitch
    {
        public const string Default = "default";
        public const string Off = "off";
        public const string On = "on";
    }
}