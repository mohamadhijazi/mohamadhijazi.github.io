﻿namespace Bot.Builder.Community.Cards.Management
{
    public static class Behaviors
    {
        public const string AutoDeactivate = "autoDeactivate";
    }
}
