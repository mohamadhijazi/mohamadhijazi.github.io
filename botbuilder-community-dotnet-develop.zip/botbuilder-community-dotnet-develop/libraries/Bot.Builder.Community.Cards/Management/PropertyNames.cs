﻿namespace Bot.Builder.Community.Cards.Management
{
    internal class PropertyNames
    {
        internal const string LibraryData = "_cardsLibrary";
    }
}