﻿namespace Bot.Builder.Community.Cards
{
    internal class AdaptiveActionTypes
    {
        public const string Submit = "Action.Submit";
    }
}