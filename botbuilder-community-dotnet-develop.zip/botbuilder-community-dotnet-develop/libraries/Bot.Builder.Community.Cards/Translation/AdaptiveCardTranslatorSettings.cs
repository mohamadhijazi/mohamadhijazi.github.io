﻿namespace Bot.Builder.Community.Cards.Translation
{
    public class AdaptiveCardTranslatorSettings
    {
        public string[] PropertiesToTranslate { get; set; }
    }
}
