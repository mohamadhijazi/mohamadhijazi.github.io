﻿namespace Bot.Builder.Community.Cards
{
    public class ContentTypes
    {
        public const string AdaptiveCard = "application/vnd.microsoft.card.adaptive";
    }
}